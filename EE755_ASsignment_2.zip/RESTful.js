/* Name: Eddie Groom                                                                                                           *
 * Date: 02.27.24                                                                                                              *
 * EE-755 Assignment #2                                                                                                        *
 *                                                                                                                             *
 * Module: RESTful.js                                                                                                          *
 *                                                                                                                             *
 * Description: RESTful.js is a RESTful API for a blogging platform using Node.js and MongoDB. The API supports                *
 * creating blog posts with associated usernames, retrieving posts by username, deleting all posts                             *
 * by a specific user, and searching for posts containing certain keywords. Each blog consists of                              *
 * three fields: userName, title, and content.                                                                                 */ 

const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require("mongodb")
const app = express();
const PORT = 3000;
dbname = "Blog"
app.use(bodyParser.json());

// Defining the DB instance, database, and collection
const uri = "mongodb://127.0.0.1"
const client = new MongoClient(uri)

async function connectToDatabase() {
    // Establish a connection to the database
    try {
    await client.connect()
    console.log("Connected to MongoDB ...")
    } catch (error) {
    console.error(`error connecting to {database}`)
    }
    }

// Endpoint adds a new blog post with a title, content, and username.
app.post('/posts', async (req, res) => {
    db = client.db(dbname)
    const collection = db.collection('posts');
    try {
    const result = await collection.insertOne(req.body);
    if (result.acknowledged) {
    res.status(200).json({ 'message': 'Post added successfully' });
    } else {
    res.status(400).send('Adding new post failed');
    }
    } catch (err) {
    console.log(err);
    res.status(500).send('Adding new post failed');
    }
    });

// An endpoint to retrieve all blog posts
app.get('/posts', async (req, res) => {
    db = client.db(dbname)
    const collection = db.collection('posts');
    try {
    const posts = await collection.find({}).toArray();
    res.json(posts);
    } catch (err) {
    console.log(err);
    res.status(500).send("Failed to fetch posts.");
    }
    });

// An endpoint to retrieve all blog posts by a given username.
app.get('/posts/user/:userName', async (req, res) => {
    db = client.db(dbname)
    const collection = db.collection('posts')
    const userName = req.params.userName
    try {
    const posts = await collection.find({ userName: { $regex: userName, $options: 'i' } }).toArray()
    res.json(posts)
    } catch (err) {
    console.log(err)
    res.status(500).send("Failed to fetch posts.")
    }
    });

// An endpoint to retrieve all blog posts by containing a given word (searchWord) in the title.
app.get('/posts/title/:searchWord', async (req, res) => {
    db = client.db(dbname)
    const collection = db.collection('posts')
    const searchWord = req.params.searchWord
    try {
    const posts = await collection.find({ title: { $regex: searchWord, $options: 'i' } }).toArray()
    res.json(posts)
    } catch (err) {
    console.log(err)
    res.status(500).send("Failed to fetch posts.")
    }
    });


// An endpoint to retrieve all blog posts containing a given word in the content.
app.get('/posts/content/:searchWord', async (req, res) => {
    db = client.db(dbname)
    const collection = db.collection('posts')
    const searchWord = req.params.searchWord
    try {
    const posts = await collection.find({ content: { $regex: searchWord, $options: 'i' } }).toArray()
    res.json(posts)
    } catch (err) {
    console.log(err)
    res.status(500).send("Failed to fetch posts.")
    }
    });

// An endpoint to delete all blogs by a given username.
app.delete('/posts/user/:userName', async (req, res) => {
    db = client.db(dbname)
    const collection = db.collection('posts')
    const userName = req.params.userName
    try {
    let posts = await collection.deleteMany({ userName: { $regex: userName, $options: 'i' } })
    posts.deletedCount > 0 ? res.send(`Deleted ${posts.deletedCount} docs`)
                            : res.send("No documents deleted")
    } catch (err) {
    console.log(err)
    res.status(500).send("Failed to delete posts.")
    }
    });

// An endpoint to delete all blogs that contain a certain word (searchWord).
app.delete('/posts/content/:searchWord', async (req, res) => {
    db = client.db(dbname)
    const collection = db.collection('posts')
    const searchWord = req.params.searchWord
    try {
    let posts = await collection.deleteMany({ content: { $regex: searchWord, $options: 'i' } })
    posts.deletedCount > 0 ? res.send(`Deleted ${posts.deletedCount} docs`)
                            : res.send("No documents deleted")
    } catch (err) {
    console.log(err)
    res.status(500).send("Failed to delete posts.")
    }
    });

// An endpoint that returns the userName and the number of blogs posted by a userName.
app.get('/posts/count/:userName', async (req, res) => {
    db = client.db(dbname)
    const collection = db.collection('posts')
    const userName = req.params.userName
    try {
    const posts = await collection.find({ userName: { $regex: userName, $options: 'i' } }).toArray()
    let docCount = collection.countDocuments()
    //res.json(posts)
    res.send('Username ' + userName + ` found in ${await docCount} documents`)
    } catch (err) {
    console.log(err)
    res.status(500).send("Failed to fetch posts.")
    }
    });

app.listen(PORT, async ()=>{
    console.log(`Connected to the Express server on port ${PORT}`)
    await connectToDatabase()
    })