/* Name: Eddie Groom                                                                                                           *
 * Date: 04.25.24                                                                                                              *
 * EE-755 Assignment #4                                                                                                        *
 *                                                                                                                             *
 * Module: vmCloud.js                                                                                                          *
 *                                                                                                                             *
 * Description: vmCloud.js is a NodeJS program to implement a REST API using theExpress server to handle REST API requests.    *
 * Using the SQL table products, the API supports creating a new product retreiving all products, retrieving a single product  *
 * based on the productID, updating a products information, and deleting a product.                                            *
 *                                                                                                                             */


require('dotenv').config()
var express = require('express');
var app = express();
const sql = require('mssql');
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

var DbUserName = process.env.DbUsername
var DbUserPassword = process.env.DbUserPassword
var DbName = process.env.DbName
var DbServerName = process.env.DbServerName

var config = {
user: DbUserName,
password: DbUserPassword,
server: DbServerName,
database: DbName
};

//Create a new product
app.post('/products', function (req, res) {
    sql.connect(config, function (err) {
    if (err) console.log(err);

    var request = new sql.Request();
    var prodQuery = "INSERT INTO products (name, price, quantity) VALUES (" + "'" + req.body.name + "'" + "," + "'" + req.body.price +"'"+ "," + "'"+req.body.quantity +"'" + ")"
    request.query(prodQuery, function (err, result) {
        if (err) {
            console.log("ERROR: " + err)
            res.send("ERROR: " + err)}
        else{
            console.log(prodQuery)
            res.send(prodQuery)
        }
    })
    });
    })


//Retrieve all products
app.get('/products', function (req, res) {
    var col  = req.body.col;
    var sign = req.body.sign;
    var val  = req.body.val;

    var queryVar = "";

    if ((col === null) && (sign === null) && (val === null))
    {
        queryVar = "select * from products";
    }
    else if(((col == 'price')|| (col == 'quantity')) &&
           ((sign == '<') || (sign == '=') || (sign == '>')) &&
           val !=  null)
    {
        queryVar = "select * from products where " + col + " " + sign + " " + val
    }
    console.log(queryVar)
    console.log(col+sign+val)

    sql.connect(config, function (err) {
    if (err) console.log(err);

    
    var request = new sql.Request();


    request.query(queryVar, function (err, result) {
    if (err) console.log("ERROR: " + err)
    console.log("rows returned: " + result.recordset.length)
    res.setHeader('Content-Type', 'text/html');
    for(let i=0; i<result.recordset.length; i++){
    console.log(result.recordset[i]);
    res.write(JSON.stringify(result.recordset[i]))
    }
    res.send()
    })
    });
    })

    //Retrieve a single product
app.get('/products/:id', function (req, res) {
    const id = req.params.id
    

    sql.connect(config, function (err) {
    if (err) console.log(err);
    var request = new sql.Request();
    request.query('select * from products where ID =' + id, function (err, result) {
    if (err) console.log("ERROR: " + err)
    console.log("rows returned: " + result.recordset.length )
    res.setHeader('Content-Type', 'text/html');
   
    console.log(result.recordset);
    res.write(JSON.stringify(result.recordset))
   
    res.send()
    })
    });
    })


//Update a single product
app.put('/products/:id', function (req, res) {
    const id = req.params.id
    

    sql.connect(config, function (err) {
    if (err) console.log(err);
    var request = new sql.Request();
    var nameVar = "";
    var priceVar = "";
    var quantityVar = "";

    if(req.body.name != null)
        nameVar = "name = '" +  req.body.name + "'"
    else
        nameVar = ""

    if(req.body.price != null && req.body.name != null)
        priceVar = ", price = '" +  req.body.price + "'"
    else if (req.body.price != null)
        priceVar = "price = '" +  req.body.price + "'"
    else
       priceVar = ""

    if( (req.body.quantity != null) && (req.body.price != null || req.body.name != null))
       quantityVar = ", quantity = '" +  req.body.quantity + "'"
    else if (req.body.quantity != null)
       quantityVar = "quantity = '" +  req.body.quantity + "'"
    else
      quantityVar = ""   

    var queryVar = "UPDATE products SET " + nameVar + priceVar + quantityVar + " WHERE ID =" + id
       
   
    request.query(queryVar, function (err, result) {
    if (err) {
        console.log("ERROR(Unable to update name): " + err)
        console.log(queryVar)
        res.status(500).send("ERROR(Unable to update name): " + err)
    }
    else{
    console.log(queryVar)
    res.send(queryVar)}
    })
   
    });
    })

//Delete a single product
app.delete('/products/:id', function (req, res) {
    const id = req.params.id
    

    sql.connect(config, function (err) {
    if (err) console.log(err);
    var request = new sql.Request();

    request.query('delete from products where ID =' + id, function (err, result) {
    if (err) {
        console.log("ERROR: " + err)
        res.status(500).send("ERROR: " + err )
    }
    else
    {
        console.log("Deleted ID: " + id )
        res.send("Deleted ID: " + id )
    }
    
    })
    });
    })

    var server = app.listen(5000, function () {
        console.log('Server is running ...');
        });