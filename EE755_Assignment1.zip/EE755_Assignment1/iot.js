/* Name: Eddie Groom                                                                                                           *
 * Date: 02.10.24                                                                                                              *
 * EE-755 Assignment #1                                                                                                        *
 *                                                                                                                             *
 * Module: iot.js                                                                                                              *
 *                                                                                                                             *
 * Description: IOT.js is an application that supports registering new devices, displaying registered devices,                 *
 * receiving data from devices, and sending commands to devices. The system maintains logs of all activities                   *
 * and persist device information.                                                                                             */

const express = require('express')
const app = express()
const bodyParser = require('body-parser');
const port = 3000

const { stat, open, writeFile, writeFileSync, readFile, readFileSync, appendFile, appendFileSync } = require('fs');
const path = './public/devices.json';

var parsedData;


deviceIdExist = false;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Serve static files
app.use(express.static('public'))

app.get('/iot.htm', function (req, res) {
    console.log("Received a GET request")
    res.sendFile( __dirname + "/" + "iot.html" )
    res.send('Hello Get')

})

logData = (logLine) => {
    // Function logs all all activities (registrations, received data, commands)
    // with timestamps to a logfile named logs.txt
    const logPath = './public/logs.txt';
    
    log = "[" + new Date().toISOString() + "] " + logLine + "\r\n";
    console.log(log);
    appendFileSync(logPath, log);
}

loadDevices = () => {
    // Function loads existing devices from devices.json into memory

    stat(path, (err, stats) => {
        if (err) {
            // Add an empty array to new JSON file
            let newRecord = 
            [
            
            ];
            writeFileSync(path,JSON.stringify(newRecord, null, 2));

        }
        console.log("File opened!!");
        data = readFileSync(path, "utf8");
        parsedData = JSON.parse(data);
      });
}

// Load existing devices from devices.json into memory on application startup
loadDevices();


app.post('/register', function (req, res) {
   deviceIdExist = false;
   logData("POST endpoint /register processed");
   

   if(req.body.deviceId != "" && req.body.deviceType != ""  )
   {        
            var newRecord = 
            {
                deviceId : req.body.deviceId,
                deviceType : req.body.deviceType,
                data : "",
                command : ""
            }
            for(let i in parsedData)
            {
                var tempReg = parsedData[i];
                if(tempReg.deviceId == req.body.deviceId)
                {
                    deviceIdExist = true;
                }
            }
            if (deviceIdExist == false)
            {
                parsedData.push(newRecord);
                console.log(newRecord);
                
                writeFile(path, JSON.stringify(parsedData, null, 2), (err) => 
                {
                    if (err) 
                    {
                        logData("Error: Failed to write updated data to file")
                        res.status(404).send("Error: Failed to write updated data to file");
                    }
                    else
                    {
                        logData("Registration File Update Successful")
                        res.status(201).send("Updated file successfully");
                    }
                });
            }
            else
            {
                logData("Error(404): DeviceID already exists")
                res.status(404).send("Error(404): DeviceID already exists");
            }

    }
    else
    {
       console.log("Error(400): Empty data fields");
       res.status(400).send("Error(400): Please Enter Valid DeviceID and DeviceType Information")
    } 
       
});
       
app.get('/show', function (req, res) {    
    logData("GET endpoint /show processed")

    res.status(201).send(JSON.stringify(parsedData, undefined, 4));
    console.log(JSON.stringify(parsedData, undefined, 4));
});

app.post('/data', function (req, res) 
{   
    deviceIdExist = false;
    logData("POST endpoint /data processed")
    if(req.body.deviceId != "" && req.body.data != "")
    {

             for(let i in parsedData)
             {
                 var tempReg = parsedData[i];
                 if(tempReg.deviceId == req.body.deviceId)
                 {
                     deviceIdExist = true;
                     tempReg.data = "[" + new Date().toISOString() + "] " + req.body.data;
                     logData("POST endpoint /data updated data")
 
                     res.status(201).send("Data field updated:" + parsedData[i].deviceId + "," + parsedData[i].deviceType + "," + parsedData[i].data +
                                          "," + parsedData[i].command );

                    writeFile(path, JSON.stringify(parsedData, null, 2), (err) => 
                    {
                        if (err) 
                        {
                          console.log('Error(400): Failed to write updated data to file');
                          logData("Error(400): Failed to write updated data to file")
                          res.status(400).send("Error(400): Failed to write updated data to file");
                        }
                    });
                 }
             }
             if (deviceIdExist == false)
             {
                 logData("Error(400): DeviceID Does Not Exist")
                 res.status(400).send("Error(400): DeviceID Does Not Exist");
             }
             logData(deviceIdExist);
    }
    else
    {
        if(req.body.deviceId == "")
        {
            logData("Error(400): Endpoint /data requires a valid DeviceID.");
            res.status(400).send("Error(400): Endpoint /data requires a valid DeviceID.");
        }
        if(req.body.data == "")
        {
            logData("Error(400): Endpoint /data requires a valid Data Entry")
            res.status(400).send("Error(400): Endpoint /data requires a valid Data Entry");
        }
        
    }

});

app.post('/command', function (req, res) 
{   
    deviceIdExist = false;
    logData("POST endpoint /command processed");
 
    if(req.body.deviceId != "" && req.body.command != "")
    {
             for(let i in parsedData)
             {
                 var tempReg = parsedData[i];
                 if(tempReg.deviceId == req.body.deviceId)
                 {
                     deviceIdExist = true;
                     tempReg.command = "[" + new Date().toISOString() + "] " + req.body.command;

                     logData("Endpoint /command updated command");

                     res.status(201).send("Command field updated:" + parsedData[i].deviceId + "," + parsedData[i].deviceType + "," + parsedData[i].data +
                                          "," + parsedData[i].command );

                    writeFile(path, JSON.stringify(parsedData, null, 2), (err) => 
                    {
                        if (err) 
                        {
                          console.log('Error(404): Failed to write updated command to file');
                          res.status(404).send("Error(404): Failed to write updated command to file");
                        
                        }
                    });
                 }
             }
             if (deviceIdExist == false)
             {
                logData("Error(404): DeviceID Does Not Exist");

                res.status(404).send("Error(404): DeviceID Does Not Exist");
             }
    }
    else
    {
        if(req.body.deviceId == "")
        {
            logData("Error(400): Endpoint /command requires a valid DeviceID.");
            res.status(400).send("Error(400): Endpoint /command requires a valid DeviceID.");
        }
        if(req.body.command == "")
        {
            logData("Error(400): Endpoint /command requires a valid Command.")
            res.status(400).send("Error(400): Endpoint /command requires a valid Command.");
        }

    }

});

var server = app.listen(port, function () {
    console.log(`Server listening on port ${port}`)
})